#!/usr/bin/env bash

LUAROCKS=ci/lua/bin/luarocks
eval $($LUAROCKS path --bin)

